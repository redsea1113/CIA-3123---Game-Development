    // Define a class called game object

    class GameObject {

       // a constructor is used to create objects

        
       // The object usually have attributes that describe the object
       // and methods for behaviour
       // as you desing the game you need to think about these objects
       // decide on these attributes and methogs
        
        
       // calls constructor
       // The objects needs intial settings and usually it is done
       // In the constructor, creating a new object or copy

       		constructor(x,y,height, width, imgName ) {
            this.height = height;
    		this.width = width;
    		this.x = x; 
    		this.y = y;
            this.speed = 10;
            this.image = new Image();
            this.image.src = imgName;
            this.alive = true;
	  }


        
    // This method draws the object itself. it knows how to draw itself
    // This example here shows a simple form way of drawing.. it can be
    // more complex with frames
  	draw(context)
    {

              context.drawImage(this.image,this.x,this.y,this.width,this.height);
	}

        
        
	// This method moves the object based on key pressed
    // In this example we are using the keyboard to control movement of the object
    // it is left to you how to implement the movement of the object.  It can be mourse or touch
    // event
        
    move(e)
	{
        
       		if (e.keyCode == 37)
       		{
          	   // move left 
                   this.x = this.x - this.speed;

	       	}
            
            if (e.keyCode == 39)
       		{
         		// move right  
         		this.x = this.x + this.speed;
      
		    }

	       if (e.keyCode == 38)
           {
          	// mover up   
               this.y = this.y - this.speed;
            }

	       if (e.keyCode == 40)
       		{
			// move down 
                this.y = this.y + this.speed;
	       }

	       if (this.x < 0)
        	   this.x = canvas.width + 8; 

	       else if (this.x >= canvas.width)
                  this.x = - 8; 
	} 

        
        
    // This method check for collision with a specific object and plays custom sound
    // if this object collides with the object being passed
    // this usually at the heart of game dvelopment and there are several
    // ways to detect collision, this is a simple for and like box interesection
        

    checkCollision(o,sound)
    {
       
        
       if  (this.x + this.width  > o.x  && this.x < (o.x + o.width) && this.y + this.height > o.y  && 
       this.y < (o.y + o.height))
  
      {

            sound.pause();
 
            sound.currentTime = 0;
 
            sound.play();


      }

    }

    // This function moves the object to the right
    // created another mothod just for moving right and left
    // you can add other function as yo see fit
        
    moveRight()
    {
	  this.x = this.x + this.speed;
      
          if (this.x >= canvas.width)
          this.x = - this.width;
	  
	}
  
    // This function moves the object to the left
    moveLeft()
   {
     
        this.x = this.x - this.speed;
        if (this.x <= 0)
             this.x = canvas.width + this.width;
        
   
  }
 }


