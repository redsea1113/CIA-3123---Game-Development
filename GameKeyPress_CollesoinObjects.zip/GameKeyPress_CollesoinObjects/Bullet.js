


// This is another object that is needed in the game
// In this class we only have few methods to be implemented releted
// to a Bullet fired from the defender spaceship

// Define a class called Bullet

    class Bullet {

       // a constructor is used to create objects
       // Same as the Game Object Class with similar methods
        

       	constructor(x,y,height, width, style ) {
   	 	this.height = height;
    		this.width = width;
    		this.x = x; 
    		this.y = y;
            this.style = style;
			this.speed = 10;
            this.alive = true;
            
	  }


    // Drawing Method
  	draw(context){

              context.fillStyle = this.style;
              context.fillRect(this.x,this.y,this.width,this.height);

	}

	// Move Method
    move(e)
	{
        this.y = this.y - this.speed;
        if (this.y + this.height < 0)
            this.alive = false;
	} 

    // Collision Method 
    checkCollision(o,sound)
    {
       
        
        if  (this.x + this.width  > o.x  && this.x < (o.x + o.width) && this.y + this.height > o.y  && this.y < (o.y + o.height))
        {
            sound.pause();
            sound.currentTime = 0;
            sound.play();
            this.alive = false;
            return true;
            
        }
        else
            return false;

    }


 }


